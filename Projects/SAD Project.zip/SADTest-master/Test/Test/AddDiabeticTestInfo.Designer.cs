﻿namespace Test
{
    partial class AddDiabeticTestInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddDiabeticTestInfo));
            this.microalbumintb = new System.Windows.Forms.TextBox();
            this.heartRatelb = new System.Windows.Forms.Label();
            this.datetestTaken = new System.Windows.Forms.DateTimePicker();
            this.footchecktb = new System.Windows.Forms.TextBox();
            this.cyvtb = new System.Windows.Forms.TextBox();
            this.eyeexamtb = new System.Windows.Forms.TextBox();
            this.counselingtb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.addDiabeticTestbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // microalbumintb
            // 
            this.microalbumintb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.microalbumintb.Location = new System.Drawing.Point(279, 63);
            this.microalbumintb.Margin = new System.Windows.Forms.Padding(4);
            this.microalbumintb.Multiline = true;
            this.microalbumintb.Name = "microalbumintb";
            this.microalbumintb.Size = new System.Drawing.Size(143, 33);
            this.microalbumintb.TabIndex = 1;
            // 
            // heartRatelb
            // 
            this.heartRatelb.AutoSize = true;
            this.heartRatelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heartRatelb.Location = new System.Drawing.Point(112, 377);
            this.heartRatelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.heartRatelb.Name = "heartRatelb";
            this.heartRatelb.Size = new System.Drawing.Size(112, 18);
            this.heartRatelb.TabIndex = 13;
            this.heartRatelb.Text = "Date Test Done";
            // 
            // datetestTaken
            // 
            this.datetestTaken.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetestTaken.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetestTaken.Location = new System.Drawing.Point(279, 377);
            this.datetestTaken.Name = "datetestTaken";
            this.datetestTaken.Size = new System.Drawing.Size(200, 24);
            this.datetestTaken.TabIndex = 6;
            this.datetestTaken.ValueChanged += new System.EventHandler(this.datetestTaken_ValueChanged);
            // 
            // footchecktb
            // 
            this.footchecktb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.footchecktb.Location = new System.Drawing.Point(279, 124);
            this.footchecktb.Margin = new System.Windows.Forms.Padding(4);
            this.footchecktb.Multiline = true;
            this.footchecktb.Name = "footchecktb";
            this.footchecktb.Size = new System.Drawing.Size(143, 33);
            this.footchecktb.TabIndex = 2;
            // 
            // cyvtb
            // 
            this.cyvtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cyvtb.Location = new System.Drawing.Point(279, 188);
            this.cyvtb.Margin = new System.Windows.Forms.Padding(4);
            this.cyvtb.Multiline = true;
            this.cyvtb.Name = "cyvtb";
            this.cyvtb.Size = new System.Drawing.Size(143, 33);
            this.cyvtb.TabIndex = 3;
            // 
            // eyeexamtb
            // 
            this.eyeexamtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eyeexamtb.Location = new System.Drawing.Point(279, 242);
            this.eyeexamtb.Margin = new System.Windows.Forms.Padding(4);
            this.eyeexamtb.Multiline = true;
            this.eyeexamtb.Name = "eyeexamtb";
            this.eyeexamtb.Size = new System.Drawing.Size(143, 33);
            this.eyeexamtb.TabIndex = 4;
            // 
            // counselingtb
            // 
            this.counselingtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.counselingtb.Location = new System.Drawing.Point(279, 304);
            this.counselingtb.Margin = new System.Windows.Forms.Padding(4);
            this.counselingtb.Multiline = true;
            this.counselingtb.Name = "counselingtb";
            this.counselingtb.Size = new System.Drawing.Size(143, 33);
            this.counselingtb.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(149, 249);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 18);
            this.label1.TabIndex = 19;
            this.label1.Text = "Eye Exam";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(127, 70);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 18);
            this.label2.TabIndex = 20;
            this.label2.Text = "Microalbumin";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(138, 131);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 18);
            this.label3.TabIndex = 21;
            this.label3.Text = "Foot Check";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(96, 195);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 18);
            this.label4.TabIndex = 22;
            this.label4.Text = "Current Year Vacc";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(72, 311);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 18);
            this.label5.TabIndex = 23;
            this.label5.Text = "Nutritional Counseling";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(635, 463);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(257, 20);
            this.label13.TabIndex = 30;
            this.label13.Text = "Note: All Fields Must be completed!";
            // 
            // addDiabeticTestbtn
            // 
            this.addDiabeticTestbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addDiabeticTestbtn.Location = new System.Drawing.Point(717, 535);
            this.addDiabeticTestbtn.Name = "addDiabeticTestbtn";
            this.addDiabeticTestbtn.Size = new System.Drawing.Size(175, 47);
            this.addDiabeticTestbtn.TabIndex = 7;
            this.addDiabeticTestbtn.Text = "Add This Information to The Patients Records";
            this.addDiabeticTestbtn.UseVisualStyleBackColor = true;
            this.addDiabeticTestbtn.Click += new System.EventHandler(this.addDiabeticTestbtn_Click);
            // 
            // AddDiabeticTestInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 594);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.addDiabeticTestbtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.counselingtb);
            this.Controls.Add(this.eyeexamtb);
            this.Controls.Add(this.cyvtb);
            this.Controls.Add(this.footchecktb);
            this.Controls.Add(this.datetestTaken);
            this.Controls.Add(this.heartRatelb);
            this.Controls.Add(this.microalbumintb);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddDiabeticTestInfo";
            this.Text = "Add Diabetic Test Info";
            this.Load += new System.EventHandler(this.AddDiabeticTestInfo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox microalbumintb;
        private System.Windows.Forms.Label heartRatelb;
        private System.Windows.Forms.DateTimePicker datetestTaken;
        private System.Windows.Forms.TextBox footchecktb;
        private System.Windows.Forms.TextBox cyvtb;
        private System.Windows.Forms.TextBox eyeexamtb;
        private System.Windows.Forms.TextBox counselingtb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button addDiabeticTestbtn;
    }
}