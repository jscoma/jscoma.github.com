﻿namespace Test
{
    partial class AddLipidTestInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddLipidTestInfo));
            this.HgA1ctb = new System.Windows.Forms.TextBox();
            this.LDLtb = new System.Windows.Forms.TextBox();
            this.trigylceridesTb = new System.Windows.Forms.TextBox();
            this.HDLtb = new System.Windows.Forms.TextBox();
            this.cholesterolTb = new System.Windows.Forms.TextBox();
            this.heartRatelb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.addLipidInfobtn = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // HgA1ctb
            // 
            this.HgA1ctb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HgA1ctb.Location = new System.Drawing.Point(233, 91);
            this.HgA1ctb.Name = "HgA1ctb";
            this.HgA1ctb.Size = new System.Drawing.Size(143, 29);
            this.HgA1ctb.TabIndex = 1;
            this.HgA1ctb.TextChanged += new System.EventHandler(this.HgA1ctb_TextChanged);
            // 
            // LDLtb
            // 
            this.LDLtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LDLtb.Location = new System.Drawing.Point(233, 276);
            this.LDLtb.Name = "LDLtb";
            this.LDLtb.Size = new System.Drawing.Size(143, 29);
            this.LDLtb.TabIndex = 4;
            // 
            // trigylceridesTb
            // 
            this.trigylceridesTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trigylceridesTb.Location = new System.Drawing.Point(233, 351);
            this.trigylceridesTb.Name = "trigylceridesTb";
            this.trigylceridesTb.Size = new System.Drawing.Size(143, 29);
            this.trigylceridesTb.TabIndex = 5;
            // 
            // HDLtb
            // 
            this.HDLtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HDLtb.Location = new System.Drawing.Point(233, 212);
            this.HDLtb.Name = "HDLtb";
            this.HDLtb.Size = new System.Drawing.Size(143, 29);
            this.HDLtb.TabIndex = 3;
            // 
            // cholesterolTb
            // 
            this.cholesterolTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cholesterolTb.Location = new System.Drawing.Point(233, 147);
            this.cholesterolTb.Name = "cholesterolTb";
            this.cholesterolTb.Size = new System.Drawing.Size(143, 29);
            this.cholesterolTb.TabIndex = 2;
            // 
            // heartRatelb
            // 
            this.heartRatelb.AutoSize = true;
            this.heartRatelb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.heartRatelb.Location = new System.Drawing.Point(97, 98);
            this.heartRatelb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.heartRatelb.Name = "heartRatelb";
            this.heartRatelb.Size = new System.Drawing.Size(55, 18);
            this.heartRatelb.TabIndex = 5;
            this.heartRatelb.Text = "HgA1C";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(68, 154);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 18);
            this.label1.TabIndex = 6;
            this.label1.Text = "Cholesterol";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(114, 219);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "HDL";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(117, 283);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 18);
            this.label3.TabIndex = 8;
            this.label3.Text = "LDL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(61, 358);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 18);
            this.label4.TabIndex = 9;
            this.label4.Text = "Triglycerides";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(233, 421);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 24);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(68, 426);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "Date Of Test";
            // 
            // addLipidInfobtn
            // 
            this.addLipidInfobtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addLipidInfobtn.Location = new System.Drawing.Point(677, 498);
            this.addLipidInfobtn.Name = "addLipidInfobtn";
            this.addLipidInfobtn.Size = new System.Drawing.Size(175, 47);
            this.addLipidInfobtn.TabIndex = 7;
            this.addLipidInfobtn.Text = "Add This Information to The Patients Records";
            this.addLipidInfobtn.UseVisualStyleBackColor = true;
            this.addLipidInfobtn.Click += new System.EventHandler(this.addLipidInfobtn_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(595, 426);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(257, 20);
            this.label13.TabIndex = 28;
            this.label13.Text = "Note: All Fields Must be completed!";
            // 
            // AddLipidTestInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 594);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.addLipidInfobtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.heartRatelb);
            this.Controls.Add(this.cholesterolTb);
            this.Controls.Add(this.HDLtb);
            this.Controls.Add(this.trigylceridesTb);
            this.Controls.Add(this.LDLtb);
            this.Controls.Add(this.HgA1ctb);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddLipidTestInfo";
            this.Text = "Add Lipid Test Info";
            this.Load += new System.EventHandler(this.AddLipidTestInfo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox HgA1ctb;
        private System.Windows.Forms.TextBox LDLtb;
        private System.Windows.Forms.TextBox trigylceridesTb;
        private System.Windows.Forms.TextBox HDLtb;
        private System.Windows.Forms.TextBox cholesterolTb;
        private System.Windows.Forms.Label heartRatelb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button addLipidInfobtn;
        private System.Windows.Forms.Label label13;
    }
}