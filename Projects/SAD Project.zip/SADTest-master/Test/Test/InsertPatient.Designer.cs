﻿namespace Test
{
    partial class InsertPatient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InsertPatient));
            this.fnTb = new System.Windows.Forms.TextBox();
            this.ctb = new System.Windows.Forms.TextBox();
            this.pitb = new System.Windows.Forms.TextBox();
            this.lnTB = new System.Windows.Forms.TextBox();
            this.stb = new System.Windows.Forms.TextBox();
            this.ptb = new System.Windows.Forms.TextBox();
            this.sitb = new System.Windows.Forms.TextBox();
            this.sttb = new System.Windows.Forms.TextBox();
            this.ztb = new System.Windows.Forms.TextBox();
            this.dbtb = new System.Windows.Forms.TextBox();
            this.dvtb = new System.Windows.Forms.TextBox();
            this.lFirstname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.insertButton = new System.Windows.Forms.Button();
            this.ntb = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.currentDatebt = new System.Windows.Forms.Button();
            this.gtb = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // fnTb
            // 
            this.fnTb.Location = new System.Drawing.Point(117, 57);
            this.fnTb.Multiline = true;
            this.fnTb.Name = "fnTb";
            this.fnTb.Size = new System.Drawing.Size(119, 31);
            this.fnTb.TabIndex = 0;
            this.fnTb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ctb
            // 
            this.ctb.Location = new System.Drawing.Point(117, 316);
            this.ctb.Multiline = true;
            this.ctb.Name = "ctb";
            this.ctb.Size = new System.Drawing.Size(119, 31);
            this.ctb.TabIndex = 5;
            this.ctb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pitb
            // 
            this.pitb.Location = new System.Drawing.Point(531, 58);
            this.pitb.Multiline = true;
            this.pitb.Name = "pitb";
            this.pitb.Size = new System.Drawing.Size(119, 31);
            this.pitb.TabIndex = 10;
            this.pitb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lnTB
            // 
            this.lnTB.Location = new System.Drawing.Point(117, 113);
            this.lnTB.Multiline = true;
            this.lnTB.Name = "lnTB";
            this.lnTB.Size = new System.Drawing.Size(119, 31);
            this.lnTB.TabIndex = 1;
            this.lnTB.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // stb
            // 
            this.stb.Location = new System.Drawing.Point(117, 267);
            this.stb.Multiline = true;
            this.stb.Name = "stb";
            this.stb.Size = new System.Drawing.Size(119, 31);
            this.stb.TabIndex = 4;
            this.stb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ptb
            // 
            this.ptb.Location = new System.Drawing.Point(117, 208);
            this.ptb.Multiline = true;
            this.ptb.Name = "ptb";
            this.ptb.Size = new System.Drawing.Size(119, 31);
            this.ptb.TabIndex = 3;
            this.ptb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // sitb
            // 
            this.sitb.Location = new System.Drawing.Point(531, 113);
            this.sitb.Multiline = true;
            this.sitb.Name = "sitb";
            this.sitb.Size = new System.Drawing.Size(119, 31);
            this.sitb.TabIndex = 11;
            this.sitb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // sttb
            // 
            this.sttb.Location = new System.Drawing.Point(117, 369);
            this.sttb.Multiline = true;
            this.sttb.Name = "sttb";
            this.sttb.Size = new System.Drawing.Size(119, 31);
            this.sttb.TabIndex = 6;
            this.sttb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // ztb
            // 
            this.ztb.Location = new System.Drawing.Point(117, 424);
            this.ztb.Multiline = true;
            this.ztb.Name = "ztb";
            this.ztb.Size = new System.Drawing.Size(119, 31);
            this.ztb.TabIndex = 7;
            this.ztb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dbtb
            // 
            this.dbtb.Location = new System.Drawing.Point(117, 477);
            this.dbtb.Multiline = true;
            this.dbtb.Name = "dbtb";
            this.dbtb.Size = new System.Drawing.Size(119, 31);
            this.dbtb.TabIndex = 8;
            this.dbtb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dvtb
            // 
            this.dvtb.Location = new System.Drawing.Point(117, 529);
            this.dvtb.Multiline = true;
            this.dvtb.Name = "dvtb";
            this.dvtb.Size = new System.Drawing.Size(119, 31);
            this.dvtb.TabIndex = 9;
            this.dvtb.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lFirstname
            // 
            this.lFirstname.AutoSize = true;
            this.lFirstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lFirstname.Location = new System.Drawing.Point(12, 57);
            this.lFirstname.Name = "lFirstname";
            this.lFirstname.Size = new System.Drawing.Size(81, 18);
            this.lFirstname.TabIndex = 11;
            this.lFirstname.Text = "First Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "Last Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 18);
            this.label2.TabIndex = 13;
            this.label2.Text = "Phone";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 267);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 18);
            this.label3.TabIndex = 14;
            this.label3.Text = "Street";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 316);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 18);
            this.label4.TabIndex = 15;
            this.label4.Text = "City";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 369);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 18);
            this.label5.TabIndex = 16;
            this.label5.Text = "State";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 477);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 18);
            this.label6.TabIndex = 17;
            this.label6.Text = "Date of Birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 424);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 18);
            this.label7.TabIndex = 18;
            this.label7.Text = "Zip";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 529);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 36);
            this.label8.TabIndex = 19;
            this.label8.Text = "Date of Last \r\nVisit";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(57, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(181, 21);
            this.label9.TabIndex = 20;
            this.label9.Text = "Demographic Information";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Sitka Subheading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(512, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 21);
            this.label10.TabIndex = 21;
            this.label10.Text = "Insurance Information";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(369, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(127, 36);
            this.label11.TabIndex = 22;
            this.label11.Text = "Primary Insurance\r\nProvider\r\n";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(369, 108);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(147, 36);
            this.label12.TabIndex = 23;
            this.label12.Text = "Secondary Insurance\r\nProvider\r\n";
            // 
            // insertButton
            // 
            this.insertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.insertButton.Location = new System.Drawing.Point(658, 514);
            this.insertButton.Name = "insertButton";
            this.insertButton.Size = new System.Drawing.Size(112, 61);
            this.insertButton.TabIndex = 24;
            this.insertButton.Text = "Submit Patient Information";
            this.insertButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.insertButton.UseVisualStyleBackColor = true;
            this.insertButton.Click += new System.EventHandler(this.insertButton_Click_1);
            // 
            // ntb
            // 
            this.ntb.Enabled = false;
            this.ntb.Location = new System.Drawing.Point(669, 294);
            this.ntb.Multiline = true;
            this.ntb.Name = "ntb";
            this.ntb.ReadOnly = true;
            this.ntb.Size = new System.Drawing.Size(119, 31);
            this.ntb.TabIndex = 25;
            this.ntb.Text = "-";
            this.ntb.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(395, 534);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(257, 20);
            this.label13.TabIndex = 26;
            this.label13.Text = "Note: All Fields Must be completed!";
            // 
            // currentDatebt
            // 
            this.currentDatebt.Location = new System.Drawing.Point(262, 529);
            this.currentDatebt.Name = "currentDatebt";
            this.currentDatebt.Size = new System.Drawing.Size(109, 31);
            this.currentDatebt.TabIndex = 27;
            this.currentDatebt.Text = "Add Todays Date";
            this.currentDatebt.UseVisualStyleBackColor = true;
            this.currentDatebt.Click += new System.EventHandler(this.currentDatebt_Click);
            // 
            // gtb
            // 
            this.gtb.Location = new System.Drawing.Point(117, 162);
            this.gtb.Multiline = true;
            this.gtb.Name = "gtb";
            this.gtb.Size = new System.Drawing.Size(119, 31);
            this.gtb.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 162);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 18);
            this.label14.TabIndex = 29;
            this.label14.Text = "Gender";
            // 
            // InsertPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 576);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.gtb);
            this.Controls.Add(this.currentDatebt);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.ntb);
            this.Controls.Add(this.insertButton);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lFirstname);
            this.Controls.Add(this.dvtb);
            this.Controls.Add(this.dbtb);
            this.Controls.Add(this.ztb);
            this.Controls.Add(this.sttb);
            this.Controls.Add(this.sitb);
            this.Controls.Add(this.ptb);
            this.Controls.Add(this.stb);
            this.Controls.Add(this.lnTB);
            this.Controls.Add(this.pitb);
            this.Controls.Add(this.ctb);
            this.Controls.Add(this.fnTb);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InsertPatient";
            this.Text = "Insert a Patients Demographic Information";
            this.Load += new System.EventHandler(this.InsertPatient_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox fnTb;
        private System.Windows.Forms.TextBox ctb;
        private System.Windows.Forms.TextBox pitb;
        private System.Windows.Forms.TextBox lnTB;
        private System.Windows.Forms.TextBox stb;
        private System.Windows.Forms.TextBox ptb;
        private System.Windows.Forms.TextBox sitb;
        private System.Windows.Forms.TextBox sttb;
        private System.Windows.Forms.TextBox ztb;
        private System.Windows.Forms.TextBox dbtb;
        private System.Windows.Forms.TextBox dvtb;
        private System.Windows.Forms.Label lFirstname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button insertButton;
        private System.Windows.Forms.TextBox ntb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button currentDatebt;
        private System.Windows.Forms.TextBox gtb;
        private System.Windows.Forms.Label label14;
    }
}