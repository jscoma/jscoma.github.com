package mazecompleter;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javax.imageio.ImageIO;

/**
 * Author: Jade Scoma Credit To: http://java-buddy.blogspot.com/ for the JavaFx
 * file chooser
 */
public class MazeCompleter extends Application {

    //globals
    public static int[][] arr = null;
    public static int width;
    public static int height;

    ImageView myImageView;
    Canvas canvas1 = new Canvas(1000, 1000);
    GraphicsContext UnfinishedMaze = canvas1.getGraphicsContext2D();
    Canvas canvas2 = new Canvas(1000, 1000);
    GraphicsContext FinishedMaze = canvas2.getGraphicsContext2D();

    @Override
    public void start(Stage primaryStage) {
        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();

        primaryStage.setX(bounds.getMinX());
        primaryStage.setY(bounds.getMinY());
        primaryStage.setWidth(bounds.getWidth());
        primaryStage.setHeight(bounds.getHeight());

        Button btnLoad = new Button("Load");
        btnLoad.setOnAction(btnLoadEventListener);

        
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(5);

        GridPane.setConstraints(btnLoad, 0, 0);
        GridPane.setConstraints(canvas1, 0, 1);
        GridPane.setConstraints(canvas2, 1, 1);
        grid.getChildren().addAll(btnLoad, canvas1, canvas2);

        Scene scene = new Scene(grid, 1250, 750);

        primaryStage.setTitle("Maze Completer");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    //prints the maze to the Canvas canvas
    private void drawCompletedMaze(GraphicsContext gc) {
        for (int i = 0; i < height; i++) {
            int iMultiplier = i * 5;
            for (int j = 0; j < width; j++) {
                int jMultiplier = j * 5;
                if (arr[j][i] == 0) {
                    gc.setFill(Color.WHITE);
                    gc.fillRect(iMultiplier, jMultiplier, 5, 5);
                } else if (arr[j][i] == 1) {
                    gc.setFill(Color.BLACK);
                    gc.fillRect(iMultiplier, jMultiplier, 5, 5);
                } else if (arr[j][i] == 2) {
                    gc.setFill(Color.BLUE);
                    gc.fillRect(iMultiplier, jMultiplier, 5, 5);
                } else if (arr[j][i] == 3) {
                    gc.setFill(Color.RED);
                    gc.fillRect(iMultiplier, jMultiplier, 5, 5);
                }
            }
        }
    }

    private void drawOriginMaze(GraphicsContext gc) {
        for (int i = 0; i < height; i++) {
            int iMultiplier = i * 5;
            for (int j = 0; j < width; j++) {
                int jMultiplier = j * 5;
                if (arr[j][i] == 0) {
                    gc.setFill(Color.WHITE);
                    gc.fillRect(iMultiplier, jMultiplier, 5, 5);
                } else if (arr[j][i] == 1) {
                    gc.setFill(Color.BLACK);
                    gc.fillRect(iMultiplier, jMultiplier, 5, 5);
                }
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    EventHandler<ActionEvent> btnLoadEventListener = new EventHandler<ActionEvent>() {

        @Override
        public void handle(ActionEvent t) {
            FileChooser fileChooser = new FileChooser();

            //Show open file dialog
            File file = fileChooser.showOpenDialog(null);

//            try {
//                BufferedImage bufferedImage = ImageIO.read(file);
//                Image image = SwingFXUtils.toFXImage(bufferedImage,null);
//                myImageView.setImage(image);
//            } catch (IOException ex) {
//                Logger.getLogger(MazeCompleter.class.getName()).log(Level.SEVERE, null, ex);
//            }
            UnfinishedMaze.setFill(Color.LIGHTGRAY);
            UnfinishedMaze.fillRect(0, 0, 1000, 1000);
            FinishedMaze.setFill(Color.LIGHTGRAY);
            FinishedMaze.fillRect(0, 0, 1000, 1000);
            BufferedImage image = null;
            BufferedImage bimg = null;
            try {
                bimg = ImageIO.read(file);
            } catch (IOException ex) {
                Logger.getLogger(MazeCompleter.class.getName()).log(Level.SEVERE, null, ex);
            }
            width = bimg.getWidth();
            height = bimg.getHeight();

            try {
                image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
                image = ImageIO.read(file);
                System.out.println("Reading Complete");
            } catch (IOException e) {
                System.out.println("Error: " + e);
            }

            //turn maze into 2d array
            arr = new int[height][width];
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    if (image.getRGB(j, i) == -1) {
                        arr[i][j] = 0;
                    } else if (image.getRGB(j, i) == -16777216) {
                        arr[i][j] = 1;
                    } else {
                        System.out.println("Error reading maze");
                    }
                }
            }
            if (arr != null) {
                drawOriginMaze(UnfinishedMaze);
            }

            //find the start and finish
            boolean start = true;
            int endHeight = 0;
            int endWidth = 0;
            int startHeight = 0;
            int startWidth = 0;
            for (int j = 1; j < width - 1; j++) {
                if (arr[1][j] == 0 && start == true) {
                    startHeight = 1;
                    startWidth = j;
                    start = false;
                } else if (arr[1][j] == 0 && start == false) {
                    endHeight = 1;
                    endWidth = j;
                } else if (arr[height - 2][j] == 0 && start == true) {
                    startHeight = height - 2;
                    startWidth = j;
                    start = false;
                } else if (arr[height - 2][j] == 0 && start == false) {
                    endHeight = height - 2;
                    endWidth = j;
                }
            }
            for (int i = 1; i < height - 1; i++) {
                if (arr[i][1] == 0 && start == true) {
                    startHeight = i;
                    startWidth = 1;
                    start = false;
                } else if (arr[i][1] == 0 && start == false) {
                    endHeight = i;
                    endWidth = 1;
                } else if (arr[i][width - 2] == 0 && start == true) {
                    startHeight = i;
                    startWidth = width - 2;
                    start = false;
                } else if (arr[i][width - 2] == 0 && start == false) {
                    endHeight = i;
                    endWidth = width - 2;
                }
            }
            arr = SolvePuzzle(arr, startHeight, startWidth, endHeight, endWidth);

            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    System.out.print(arr[i][j] + "   ");
                }
                System.out.println();
            }
            System.out.println();

            if (arr != null) {
                drawCompletedMaze(FinishedMaze);
            }
        }

    };

    private static int[][] SolvePuzzle(int[][] arr, int startHeight, int startWidth, int endHeight, int endWidth) {
        try{
        arr[startHeight][startWidth] = 2;

        if (arr[endHeight][endWidth] != 2) {

            if (arr[startHeight][startWidth - 1] == 0 && startWidth != 1) {
                SolvePuzzle(arr, startHeight, startWidth - 1, endHeight, endWidth);
            } else if (arr[startHeight + 1][startWidth] == 0 && startHeight != width - 2) {
                SolvePuzzle(arr, startHeight + 1, startWidth, endHeight, endWidth);
            } else if (arr[startHeight][startWidth + 1] == 0) {
                SolvePuzzle(arr, startHeight, startWidth + 1, endHeight, endWidth);
            } else if (arr[startHeight - 1][startWidth] == 0) {
                SolvePuzzle(arr, startHeight - 1, startWidth, endHeight, endWidth);
            } else if (arr[startHeight][startWidth - 1] == 2) {
                arr[startHeight][startWidth] = 3;
                SolvePuzzle(arr, startHeight, startWidth - 1, endHeight, endWidth);
            } else if (arr[startHeight + 1][startWidth] == 2) {
                arr[startHeight][startWidth] = 3;
                SolvePuzzle(arr, startHeight + 1, startWidth, endHeight, endWidth);
            } else if (arr[startHeight][startWidth + 1] == 2) {
                arr[startHeight][startWidth] = 3;
                SolvePuzzle(arr, startHeight, startWidth + 1, endHeight, endWidth);
            } else if (arr[startHeight - 1][startWidth] == 2) {
                arr[startHeight][startWidth] = 3;
                SolvePuzzle(arr, startHeight - 1, startWidth, endHeight, endWidth);
            }

        }
        }catch(Exception e){
            System.out.println("Error: " + e);
        }
        return arr;
    }

}
