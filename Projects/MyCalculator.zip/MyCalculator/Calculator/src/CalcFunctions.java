
import java.util.ArrayList;
import java.util.Stack;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Owner
 */
public class CalcFunctions {
 
    static ArrayList<String> history = new ArrayList<String>();
            
    public static Stack parseMultDiv(String input){
        Stack parser = new Stack();
        String operand = "";
        for(int i=0; i < input.length(); i++){
            if(input.charAt(i) == '-' && input.charAt(i+1) != ' '){
                operand += input.charAt(i);
            }
            else if(input.charAt(i) != '*' && input.charAt(i) != '/' && input.charAt(i) != '+' && input.charAt(i) != '-' && input.charAt(i) != ' '){
                operand += input.charAt(i);
            }
            else if (input.charAt(i) == ' '){
                if(operand != ""){
                    parser.push(operand);
                    operand = "";
                }
            }
            else if((input.charAt(i) == '+' || input.charAt(i) == '-') && input.charAt(i+1) == ' '){
                parser.push(input.charAt(i));
            }
            else if(input.charAt(i) == '*'){
                float firstOp = Float.parseFloat((String)parser.pop());
                i = i+2;
                while(i < input.length() && input.charAt(i) != ' '){
                    operand += input.charAt(i);
                    i++;
                }
                parser.push(String.valueOf(firstOp*Float.parseFloat(operand)));
                operand = "";
            }
            else if(input.charAt(i) == '/'){
                float firstOp = Float.parseFloat((String)parser.pop());
                i = i+2;
                while(i < input.length() && input.charAt(i) != ' '){
                    operand += input.charAt(i);
                    i++;
                }
                parser.push(String.valueOf(firstOp/Float.parseFloat(operand)));
                operand = "";
            }    
        }
        if(operand != ""){
        parser.push(operand);
        }
        
        return parser;
    }    
    
    
    public static Stack reverseStack(Stack parser){
        Stack reverse = new Stack();
        while(!parser.empty()){
            reverse.push(parser.pop());
        }
        return reverse;
    }
    
    
    public static String parseAddSub(Stack parser){
            while(!parser.empty()){
            float firstOp = Float.parseFloat((String)parser.pop());
            
            if(!parser.empty()){
                char operator = (char)parser.pop();
                float secondOp = Float.parseFloat((String)parser.pop());
            
                if(operator == '+'){
                   parser.push(String.valueOf(firstOp + secondOp));
                }
                if(operator == '-'){
                   parser.push(String.valueOf(firstOp - secondOp));
                }
            }
            else
                return String.valueOf(firstOp);
        }
            return "";
    }
    
    
    public static void addHistory(String output){
        history.add(output);
    }
    
    public static ArrayList getHistory(){
        return history;
    }
    
}
